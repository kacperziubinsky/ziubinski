<script setup>
useHead({
  titleTemplate: '%s - Meta Tags Example'
})
</script>
<template>
  <NuxtLayout>
    <NuxtPage />
  </NuxtLayout>
</template>