export default {
  // Tryb generacji aplikacji statycznej
  target: 'static',

  // Tryb SPA
  ssr: false,
  
  // Konfiguracja routera
  router: {
    base: '/nowa/' // Bazowy katalog aplikacji na serwerze
  },

  // Globalne ustawienia CSS
  css: ['~/assets/css/main.css'],

  // Konfiguracja serwera deweloperskiego
  server: {
    port: 3000, // Port serwera (możesz zmienić na odpowiedni dla Twoich potrzeb)
    host: 'localhost' // Host serwera
  },

  // Konfiguracja certyfikatu SSL (jeśli wymagane)
  serverMiddleware: [
    'redirect-ssl'
  ],

  // Ustawienia dodatkowe
  // ...
}
