<template>
    <section>
      <p>This page will be displayed at the /about route.</p>
    </section>
  </template>

<script setup>
useSeoMeta({
  title: 'About page',
  description: 'This is the about page',
})
</script>